---
name: Warm Editorial Studio
colors:
  surface: '#fdf9f0'
  surface-dim: '#dddad1'
  surface-bright: '#fdf9f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ea'
  surface-container: '#f1eee5'
  surface-container-high: '#ece8df'
  surface-container-highest: '#e6e2d9'
  on-surface: '#1c1c16'
  on-surface-variant: '#444748'
  inverse-surface: '#31302b'
  inverse-on-surface: '#f4f0e7'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#855400'
  on-secondary: '#ffffff'
  secondary-container: '#fda61d'
  on-secondary-container: '#684100'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#291800'
  on-tertiary-container: '#b47700'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffddb7'
  secondary-fixed-dim: '#ffb95d'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffddb4'
  tertiary-fixed-dim: '#ffb952'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#633f00'
  background: '#fdf9f0'
  on-background: '#1c1c16'
  surface-variant: '#e6e2d9'
typography:
  display-xl:
    fontFamily: Outfit
    fontSize: 72px
    fontWeight: '800'
    lineHeight: 80px
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Outfit
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 46px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-lg:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system channels an expressive, playful-yet-authoritative creative portfolio aesthetic. Tailored for independent creative directors, multidisciplinary designers, and bespoke creative studios, it balances structured editorial rigor with energetic joy.

### Style Attributes
- **Playful Professionalism:** Elevated craft and typographic precision met with witty, dynamic visual accents.
- **Warm Tactility:** Replaces stark sterile tech minimalism with warm, organic base tones reminiscent of heavyweight unbleached paper and print editorial design.
- **Graphic Contrast:** High-contrast pairing of deep jet black against sunlit cream, punctuated by an electric warm amber-orange punch.
- **Motif & Accents:** Geometric 4-point sparkle stars (*astroids*), circular arrow badges, and tactile pill containers create instant recognition. No skeuomorphic gradients, no cold tech blues, and no fuzzy drop shadows.

## Colors

The palette is strictly tuned around organic warmth and graphic punch, avoiding cool blue or violet undertones.

### Roles & Tokens
- **Background / Canvas (`#F5F1E8`):** The master canvas tone. Soft, warm cream that creates an editorial paper feel across the entire viewport.
- **Surface / Card Layer (`#FFFFFF`):** Pure white container surfaces placed on the warm cream canvas to establish structural grouping and crisp framing.
- **Primary / Ink (`#111111`):** Deep near-black used for primary text, solid graphic buttons, structural borders, and punchy icons.
- **Secondary Accent (`#FFA81F`):** Vivid warm marigold/amber orange. Applied to callout pills, hover highlights, active badges, and animated star accents.
- **Tertiary Accent (`#F5A300`):** Rich sun-gold for interactive hover states, micro-focus borders, and deep badge highlights.
- **Muted Neutral (`#7A756D`):** Earthy mid-tone gray-brown for secondary metadata, timestamps, and subtle field helper labels.
- **Subtle Stroke (`#E6E0D4`):** Warm tonal hairline divider applied only when card separation requires micro-delineation against cream backgrounds.

## Typography

The typographic hierarchy juxtaposes bold, sculpted geometric headlines with warm, ultra-legible humanist sans body text.

### Pairings
- **Headlines & Display (`Outfit`):** High personality, rounded geometry, and tight tracking produce a commanding presence in hero intros and portfolio case study titles.
- **Body & Captions (`Plus Jakarta Sans`):** Warm, inviting, and open counters keep project descriptions, client testimonials, and long-form writing effortless to read.
- **Labels & Micro-UI (`Outfit`):** Pill tags, buttons, badges, and project metadata adopt medium-to-bold weights with slight letter-spacing to reinforce structure.

## Layout & Spacing

A fluid grid system that flexes with generous breathing room, accentuating editorial layouts and expansive work showcases.

### Grid & Breakpoints
- **Mobile (< 768px):** 4-column layout with 20px outer margin and 16px gutter. Compact card stacks with full-width action pills.
- **Tablet (768px - 1024px):** 8-column layout with 40px outer margin and 24px gutter. 2-column project grids.
- **Desktop (> 1024px):** 12-column layout maxing out at 1440px wide, 64px outer margin, and 32px gutters. Asymmetric editorial masonry layouts are encouraged.

### Spatial Rhythm
- Generous outer margins allow the warm `#F5F1E8` backdrop to frame crisp `#FFFFFF` project cards.
- Content gaps favor open pacing: `space-xl` separates distinct case studies and bio sections, while `space-md` anchors components inside modular cards.

## Elevation & Depth

This system intentionally eliminates blur shadows, skeuomorphic gradients, and colored halos in favor of crisp **tonal layering** and **flat graphical elevation**.

### Principles
- **Base Canvas Layer:** Warm cream `#F5F1E8` acts as the foundational zero-elevation floor.
- **Container Layer:** Pure white `#FFFFFF` cards sit flat on top of the cream canvas. The stark tonal delta between `#FFFFFF` and `#F5F1E8` defines the boundary naturally without requiring drop shadows.
- **Hard Contrast Boundaries:** When explicit separation is needed for interactive cards or floating elements, a flat hairline border of `1.5px solid #111111` or `1px solid #E6E0D4` is applied.
- **Interactive Offset:** Hover states achieve elevation purely through slight physical translation (e.g., `translateY(-4px)`) or by revealing a solid, unblurred hard shadow (`4px 4px 0px #111111`).

## Shapes

The shape system embraces large, bold, tactile curvature. 

### Geometry Rules
- **Large Cards & Surfaces:** Scaled at `rounded-xl` (24px to 32px border radius). This curvature softens massive display cards and embeds a warm, friendly touch.
- **Buttons, Tags & Filter Badges:** Full pill shape (`roundedness: 3` / 9999px border radius).
- **Icon Circles:** Perfect 1:1 circle containers (`border-radius: 50%`) embedded within pill buttons.
- **Sparkle Star Accent:** 4-point geometric star polygons (`astroids`) used as decorative micro-accents alongside headlines, on card corners, and as bullet separators.

## Components

### Buttons
- **Primary Pill:** Background `#111111`, text `#FFFFFF`, full pill radius (`9999px`), padding `12px 16px 12px 24px`. Contains an embedded circular badge (`36px x 36px`, background `#FFA81F`, icon `#111111`) holding a directional arrow rotated at 45 degrees (`↗`). Hover rotates arrow to 90 degrees and translates element up by 2px.
- **Secondary Pill:** Background `#FFFFFF`, border `1.5px solid #111111`, text `#111111`. Embedded circle badge in `#F5F1E8` with black icon.
- **Accent Pill:** Solid `#FFA81F` fill with `#111111` text and an embedded `#111111` circle badge holding a pure white arrow icon.

### Project Cards
- Pure `#FFFFFF` surface with `24px` to `32px` corner radius.
- Overflow hidden to house full-bleed project imagery.
- Bottom details panel with high-contrast `#111111` title in `headline-md`, pill tags, and a prominent floating circular arrow action button.

### Tags & Chips
- Fully rounded pills (`border-radius: 9999px`) using `label-sm` tracking.
- Neutral variant: Background `#F5F1E8`, text `#111111`, no border.
- Active variant: Background `#FFA81F`, text `#111111`, font weight bold.

### Form Inputs
- Background `#FFFFFF`, rounded `16px`, height `56px`, padding `0 20px`.
- Border `1.5px solid #E6E0D4`. Focus state shifts to `2px solid #111111` with no fuzzy glow rings.
- Label positioned cleanly above in `label-md` with `#111111`.

### Checkboxes & Radio Controls
- Checkboxes: `22px x 22px` with `6px` corner radius, `2px solid #111111`. Checked state fills `#111111` with a `#FFA81F` checkmark.
- Radio buttons: `22px x 22px` circular rings, `2px solid #111111`. Selected state features an inner `#FFA81F` solid dot (`10px`).

### Decorative Star Accent
- 4-point concave sparkle star SVG (`astroid`), vector-filled with `#FFA81F` or `#111111`. Sized dynamically between `16px` and `32px`. Used as marquee delimiters, floating hero decorators, and hover-triggered micro-animations.